
public class Source4 {
	public static void main(String[] args) {
		System.out.println("test4");
        System.out.println("test4");
	}
}
