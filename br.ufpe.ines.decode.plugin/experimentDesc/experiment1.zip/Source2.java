
public class Source2 {
	public static void main(String[] args) {
		System.out.println("test2");
	}
}
